var axios = require('axios').default
var url = 'https://maps.googleapis.com/maps/api/distancematrix/json?origins=-6.973858,107.632707&destinations=-6.991065,107.631785&key=AIzaSyCoX3SOCOsCPHHFAr3PyW2Mm-4pui2MNYs'

console.log(1.829482.toFixed(1))