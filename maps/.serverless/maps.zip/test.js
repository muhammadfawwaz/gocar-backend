const a = [1,2,3,4,5,6,7]
console.log([...a.slice(0,4)])