var crypto = require('crypto');
const generateUUID = () => crypto.randomBytes(16).toString("hex");

console.log('aaaaAAA'.toLowerCase())